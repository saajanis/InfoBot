These files are created with SQLDumpSplitter 2.
If you want to restore the dump, you have to execute the file saajanisfedina_DataStructure.sql first because it contains the structure like Tables.
After that, you can execute the other .sql-files as they contain the data of the now existing tables.
SQLDumpSplitter 2 by Philip Lehmann-B�hm
E-Mail: Philip@PhilipLB.de
Homepage: http://www.PhilipLB.de
