-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 182.50.133.145
-- Generation Time: Feb 10, 2014 at 10:31 AM
-- Server version: 5.0.96
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `saajanisfedina`
--

-- --------------------------------------------------------

--
-- Table structure for table `additional_exams`
--

CREATE TABLE `additional_exams` (
  `id` int(11) NOT NULL auto_increment,
  `additional_exam_group_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `start_time` datetime default NULL,
  `end_time` datetime default NULL,
  `maximum_marks` int(11) default NULL,
  `minimum_marks` int(11) default NULL,
  `grading_level_id` int(11) default NULL,
  `weightage` int(11) default '0',
  `event_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `additional_exams`
--

INSERT INTO `additional_exams` VALUES(1, 1, 332, '2012-12-19 12:38:00', '2012-12-19 12:39:00', 10, 4, NULL, 0, 270, '2013-02-15 07:09:44', '2013-02-15 07:09:44');

-- --------------------------------------------------------

--
-- Table structure for table `additional_exam_groups`
--

CREATE TABLE `additional_exam_groups` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `exam_type` varchar(255) collate utf8_unicode_ci default NULL,
  `is_published` tinyint(1) default '0',
  `result_published` tinyint(1) default '0',
  `students_list` varchar(255) collate utf8_unicode_ci default NULL,
  `exam_date` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `additional_exam_groups`
--

INSERT INTO `additional_exam_groups` VALUES(1, 'second sessional', 15, 'Marks', 0, 0, '1035,1036,1037,1041,1043,1044,1045,1046,1048,1049,1050,1051,1054,1055,1060,1063,1065,1068,1070,1072,1074,1076,1078,1080,1082,1085,1092,1093,1101,1102,1103,1105,1107,1108,1112,1114,1116,1117,1436,1437,1438,1439,1440,1441,1442,1443,1444,1445,1446,1447,1451,', '2013-02-15');

-- --------------------------------------------------------

--
-- Table structure for table `additional_exam_scores`
--

CREATE TABLE `additional_exam_scores` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `additional_exam_id` int(11) default NULL,
  `marks` decimal(7,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `remarks` varchar(255) collate utf8_unicode_ci default NULL,
  `is_failed` tinyint(1) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `additional_exam_scores`
--


-- --------------------------------------------------------

--
-- Table structure for table `additional_fields`
--

CREATE TABLE `additional_fields` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `additional_fields`
--


-- --------------------------------------------------------

--
-- Table structure for table `apply_leaves`
--

CREATE TABLE `apply_leaves` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `employee_leave_types_id` int(11) default NULL,
  `is_half_day` tinyint(1) default NULL,
  `start_date` date default NULL,
  `end_date` date default NULL,
  `reason` varchar(255) collate utf8_unicode_ci default NULL,
  `approved` tinyint(1) default '0',
  `viewed_by_manager` tinyint(1) default '0',
  `manager_remark` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `apply_leaves`
--


-- --------------------------------------------------------

--
-- Table structure for table `archived_employees`
--

CREATE TABLE `archived_employees` (
  `id` int(11) NOT NULL auto_increment,
  `employee_category_id` int(11) default NULL,
  `employee_number` varchar(255) collate utf8_unicode_ci default NULL,
  `joining_date` date default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `middle_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `gender` tinyint(1) default NULL,
  `job_title` varchar(255) collate utf8_unicode_ci default NULL,
  `employee_position_id` int(11) default NULL,
  `employee_department_id` int(11) default NULL,
  `reporting_manager_id` int(11) default NULL,
  `employee_grade_id` int(11) default NULL,
  `qualification` varchar(255) collate utf8_unicode_ci default NULL,
  `experience_detail` text collate utf8_unicode_ci,
  `experience_year` int(11) default NULL,
  `experience_month` int(11) default NULL,
  `status` tinyint(1) default NULL,
  `status_description` varchar(255) collate utf8_unicode_ci default NULL,
  `date_of_birth` date default NULL,
  `marital_status` varchar(255) collate utf8_unicode_ci default NULL,
  `children_count` int(11) default NULL,
  `father_name` varchar(255) collate utf8_unicode_ci default NULL,
  `mother_name` varchar(255) collate utf8_unicode_ci default NULL,
  `husband_name` varchar(255) collate utf8_unicode_ci default NULL,
  `blood_group` varchar(255) collate utf8_unicode_ci default NULL,
  `nationality_id` int(11) default NULL,
  `home_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `home_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `home_city` varchar(255) collate utf8_unicode_ci default NULL,
  `home_state` varchar(255) collate utf8_unicode_ci default NULL,
  `home_country_id` int(11) default NULL,
  `home_pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `office_city` varchar(255) collate utf8_unicode_ci default NULL,
  `office_state` varchar(255) collate utf8_unicode_ci default NULL,
  `office_country_id` int(11) default NULL,
  `office_pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `mobile_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `home_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `fax` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_file_name` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_content_type` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_data` mediumblob,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `photo_file_size` int(11) default NULL,
  `former_id` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=43 ;

--
-- Dumping data for table `archived_employees`
--

INSERT INTO `archived_employees` VALUES(1, 2, 'vishald', '2011-01-04', 'Vishal', '', 'Dewan', 1, '', 5, 2, 2, 6, '', '', NULL, NULL, 0, 'Left', '1978-05-10', 'Single', NULL, '', '', '', '', 76, '', '', '', '', 76, '', '', '', '', '', 76, '', '', '', '', '', 'vishal.cse@mietjammu.in', '', NULL, NULL, NULL, '2012-01-25 12:44:49', '2012-08-06 10:09:00', NULL, '149');

-- --------------------------------------------------------

--
-- Table structure for table `archived_employee_additional_details`
--

CREATE TABLE `archived_employee_additional_details` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `additional_field_id` int(11) default NULL,
  `additional_info` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `archived_employee_additional_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `archived_employee_bank_details`
--

CREATE TABLE `archived_employee_bank_details` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `bank_field_id` int(11) default NULL,
  `bank_info` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `archived_employee_bank_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `archived_employee_salary_structures`
--

CREATE TABLE `archived_employee_salary_structures` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `payroll_category_id` int(11) default NULL,
  `amount` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `archived_employee_salary_structures`
--


-- --------------------------------------------------------

--
-- Table structure for table `archived_exam_scores`
--

CREATE TABLE `archived_exam_scores` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `exam_id` int(11) default NULL,
  `marks` decimal(7,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `remarks` varchar(255) collate utf8_unicode_ci default NULL,
  `is_failed` tinyint(1) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_archived_exam_scores_on_student_id_and_exam_id` (`student_id`,`exam_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

--
-- Dumping data for table `archived_exam_scores`
--

INSERT INTO `archived_exam_scores` VALUES(1, 2, 148, 17.00, NULL, '', NULL, '2012-12-17 09:07:16', '2012-12-17 09:14:44');

-- --------------------------------------------------------

--
-- Table structure for table `archived_guardians`
--

CREATE TABLE `archived_guardians` (
  `id` int(11) NOT NULL auto_increment,
  `ward_id` int(11) default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `relation` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `mobile_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `city` varchar(255) collate utf8_unicode_ci default NULL,
  `state` varchar(255) collate utf8_unicode_ci default NULL,
  `country_id` int(11) default NULL,
  `dob` date default NULL,
  `occupation` varchar(255) collate utf8_unicode_ci default NULL,
  `income` varchar(255) collate utf8_unicode_ci default NULL,
  `education` varchar(255) collate utf8_unicode_ci default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `archived_guardians`
--

INSERT INTO `archived_guardians` VALUES(1, 1, 'Daljit Singh', '', 'father', '', '', '', '', '', '', '', '', 76, NULL, '', '', '', '2011-12-30 13:15:53', '2011-12-30 13:15:53');

-- --------------------------------------------------------

--
-- Table structure for table `archived_students`
--

CREATE TABLE `archived_students` (
  `id` int(11) NOT NULL auto_increment,
  `admission_no` varchar(255) collate utf8_unicode_ci default NULL,
  `class_roll_no` varchar(255) collate utf8_unicode_ci default NULL,
  `admission_date` date default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `middle_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `date_of_birth` date default NULL,
  `gender` varchar(255) collate utf8_unicode_ci default NULL,
  `blood_group` varchar(255) collate utf8_unicode_ci default NULL,
  `birth_place` varchar(255) collate utf8_unicode_ci default NULL,
  `nationality_id` int(11) default NULL,
  `language` varchar(255) collate utf8_unicode_ci default NULL,
  `religion` varchar(255) collate utf8_unicode_ci default NULL,
  `student_category_id` int(11) default NULL,
  `address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `city` varchar(255) collate utf8_unicode_ci default NULL,
  `state` varchar(255) collate utf8_unicode_ci default NULL,
  `pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `country_id` int(11) default NULL,
  `phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_file_name` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_content_type` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_data` mediumblob,
  `status_description` varchar(255) collate utf8_unicode_ci default NULL,
  `is_active` tinyint(1) default '1',
  `is_deleted` tinyint(1) default '0',
  `immediate_contact_id` int(11) default NULL,
  `is_sms_enabled` tinyint(1) default '1',
  `former_id` varchar(255) collate utf8_unicode_ci default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `photo_file_size` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `archived_students`
--

INSERT INTO `archived_students` VALUES(1, '423-10', NULL, '2010-10-08', 'Balbir ', '', 'Singh', 19, '1993-06-21', 'm', '', '', 76, '', '', NULL, '', '', '', '', '', 76, '', '', 'noreply423-10@fedena.com', NULL, NULL, NULL, '', 0, 0, NULL, 1, '971', '2011-12-30 13:15:40', '2012-10-26 06:07:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `amount` int(11) default NULL,
  `is_inactive` tinyint(1) default '0',
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `assets`
--


-- --------------------------------------------------------

--
-- Table structure for table `attendances`
--

CREATE TABLE `attendances` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `period_table_entry_id` int(11) default NULL,
  `forenoon` tinyint(1) default '0',
  `afternoon` tinyint(1) default '0',
  `reason` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33216 ;

--
-- Dumping data for table `attendances`
--

INSERT INTO `attendances` VALUES(6, 445, 8285, 1, 1, 'bunk');

-- --------------------------------------------------------

--
-- Table structure for table `bank_fields`
--

CREATE TABLE `bank_fields` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bank_fields`
--


-- --------------------------------------------------------

--
-- Table structure for table `batches`
--

CREATE TABLE `batches` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `course_id` int(11) default NULL,
  `start_date` datetime default NULL,
  `end_date` datetime default NULL,
  `is_active` tinyint(1) default '1',
  `is_deleted` tinyint(1) default '0',
  `employee_id` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_batches_on_is_deleted_and_is_active` (`is_deleted`,`is_active`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `batches`
--

INSERT INTO `batches` VALUES(1, 'BECSA', 1, '2011-09-14 00:00:00', '2012-09-26 00:00:00', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `batch_events`
--

CREATE TABLE `batch_events` (
  `id` int(11) NOT NULL auto_increment,
  `event_id` int(11) default NULL,
  `batch_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_batch_events_on_batch_id` (`batch_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=384 ;

--
-- Dumping data for table `batch_events`
--

INSERT INTO `batch_events` VALUES(1, 1, 2, '2012-05-16 11:15:27', '2012-05-16 11:15:27');

-- --------------------------------------------------------

--
-- Table structure for table `batch_students`
--

CREATE TABLE `batch_students` (
  `student_id` int(11) default NULL,
  `batch_id` int(11) default NULL,
  KEY `index_batch_students_on_batch_id_and_student_id` (`batch_id`,`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `batch_students`
--


-- --------------------------------------------------------

--
-- Table structure for table `class_timings`
--

CREATE TABLE `class_timings` (
  `id` int(11) NOT NULL auto_increment,
  `batch_id` int(11) default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `start_time` time default NULL,
  `end_time` time default NULL,
  `is_break` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_class_timings_on_batch_id_and_start_time_and_end_time` (`batch_id`,`start_time`,`end_time`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=373 ;

--
-- Dumping data for table `class_timings`
--

INSERT INTO `class_timings` VALUES(51, 8, '1', '10:00:00', '10:55:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `configurations`
--

CREATE TABLE `configurations` (
  `id` int(11) NOT NULL auto_increment,
  `config_key` varchar(255) collate utf8_unicode_ci default NULL,
  `config_value` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_configurations_on_config_key` (`config_key`(10)),
  KEY `index_configurations_on_config_value` (`config_value`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `configurations`
--

INSERT INTO `configurations` VALUES(1, 'InstitutionName', 'MIET');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=196 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` VALUES(1, 'Afghanistan');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL auto_increment,
  `course_name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `section_name` varchar(255) collate utf8_unicode_ci default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` VALUES(1, 'BE(CSE)', 'BECSA', 'A', 1, '2011-09-14 06:49:02', '2011-09-20 09:57:31');

-- --------------------------------------------------------

--
-- Table structure for table `electives`
--

CREATE TABLE `electives` (
  `id` int(11) NOT NULL auto_increment,
  `elective_group_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `electives`
--


-- --------------------------------------------------------

--
-- Table structure for table `elective_groups`
--

CREATE TABLE `elective_groups` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `elective_groups`
--

INSERT INTO `elective_groups` VALUES(1, 'MCA', 6, 1, '2013-02-02 09:59:11', '2013-02-02 10:03:25');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL auto_increment,
  `employee_category_id` int(11) default NULL,
  `employee_number` varchar(255) collate utf8_unicode_ci default NULL,
  `joining_date` date default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `middle_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `gender` tinyint(1) default NULL,
  `job_title` varchar(255) collate utf8_unicode_ci default NULL,
  `employee_position_id` int(11) default NULL,
  `employee_department_id` int(11) default NULL,
  `reporting_manager_id` int(11) default NULL,
  `employee_grade_id` int(11) default NULL,
  `qualification` varchar(255) collate utf8_unicode_ci default NULL,
  `experience_detail` text collate utf8_unicode_ci,
  `experience_year` int(11) default NULL,
  `experience_month` int(11) default NULL,
  `status` tinyint(1) default NULL,
  `status_description` varchar(255) collate utf8_unicode_ci default NULL,
  `date_of_birth` date default NULL,
  `marital_status` varchar(255) collate utf8_unicode_ci default NULL,
  `children_count` int(11) default NULL,
  `father_name` varchar(255) collate utf8_unicode_ci default NULL,
  `mother_name` varchar(255) collate utf8_unicode_ci default NULL,
  `husband_name` varchar(255) collate utf8_unicode_ci default NULL,
  `blood_group` varchar(255) collate utf8_unicode_ci default NULL,
  `nationality_id` int(11) default NULL,
  `home_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `home_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `home_city` varchar(255) collate utf8_unicode_ci default NULL,
  `home_state` varchar(255) collate utf8_unicode_ci default NULL,
  `home_country_id` int(11) default NULL,
  `home_pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `office_city` varchar(255) collate utf8_unicode_ci default NULL,
  `office_state` varchar(255) collate utf8_unicode_ci default NULL,
  `office_country_id` int(11) default NULL,
  `office_pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `mobile_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `home_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `fax` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_file_name` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_content_type` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_data` mediumblob,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `photo_file_size` int(11) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_employees_on_employee_number` (`employee_number`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=217 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` VALUES(1, 1, 'admin', '2011-09-14', 'Fedena', NULL, 'Administrator', NULL, NULL, 1, 1, NULL, 1, NULL, NULL, NULL, NULL, 1, NULL, '2010-09-14', NULL, NULL, NULL, NULL, NULL, NULL, 76, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'noreplyadmin@fedena.com', NULL, NULL, NULL, NULL, '2011-09-14 06:03:50', '2011-09-14 06:03:50', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `employees_subjects`
--

CREATE TABLE `employees_subjects` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_employees_subjects_on_subject_id` (`subject_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=714 ;

--
-- Dumping data for table `employees_subjects`
--

INSERT INTO `employees_subjects` VALUES(2, 6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `employee_additional_details`
--

CREATE TABLE `employee_additional_details` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `additional_field_id` int(11) default NULL,
  `additional_info` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `employee_additional_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `employee_attendances`
--

CREATE TABLE `employee_attendances` (
  `id` int(11) NOT NULL auto_increment,
  `attendance_date` date default NULL,
  `employee_id` int(11) default NULL,
  `employee_leave_type_id` int(11) default NULL,
  `reason` varchar(255) collate utf8_unicode_ci default NULL,
  `is_half_day` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `employee_attendances`
--

INSERT INTO `employee_attendances` VALUES(1, '2012-04-05', 3, 1, 'work', 0);

-- --------------------------------------------------------

--
-- Table structure for table `employee_bank_details`
--

CREATE TABLE `employee_bank_details` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `bank_field_id` int(11) default NULL,
  `bank_info` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `employee_bank_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `employee_categories`
--

CREATE TABLE `employee_categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `prefix` varchar(255) collate utf8_unicode_ci default NULL,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `employee_categories`
--

INSERT INTO `employee_categories` VALUES(1, 'Fedena Admin', 'Admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee_departments`
--

CREATE TABLE `employee_departments` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `employee_departments`
--

INSERT INTO `employee_departments` VALUES(1, 'Admin', 'Fedena Admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee_department_events`
--

CREATE TABLE `employee_department_events` (
  `id` int(11) NOT NULL auto_increment,
  `event_id` int(11) default NULL,
  `employee_department_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `employee_department_events`
--


-- --------------------------------------------------------

--
-- Table structure for table `employee_grades`
--

CREATE TABLE `employee_grades` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `priority` int(11) default NULL,
  `status` tinyint(1) default NULL,
  `max_hours_day` int(11) default NULL,
  `max_hours_week` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `employee_grades`
--

INSERT INTO `employee_grades` VALUES(1, 'Fedena Admin', 0, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee_leaves`
--

CREATE TABLE `employee_leaves` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `employee_leave_type_id` int(11) default NULL,
  `leave_count` decimal(5,1) default '0.0',
  `leave_taken` decimal(5,1) default '0.0',
  `reset_date` date default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=210 ;

--
-- Dumping data for table `employee_leaves`
--

INSERT INTO `employee_leaves` VALUES(1, 1, 1, 18.0, 0.0, NULL, '2011-09-21 07:08:29', '2011-09-21 07:08:29');

-- --------------------------------------------------------

--
-- Table structure for table `employee_leave_types`
--

CREATE TABLE `employee_leave_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `status` tinyint(1) default NULL,
  `max_leave_count` varchar(255) collate utf8_unicode_ci default NULL,
  `carry_forward` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `employee_leave_types`
--

INSERT INTO `employee_leave_types` VALUES(1, 'Casual', 'C', 1, '18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `employee_positions`
--

CREATE TABLE `employee_positions` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `employee_category_id` int(11) default NULL,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `employee_positions`
--

INSERT INTO `employee_positions` VALUES(1, 'Fedena Admin', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee_salary_structures`
--

CREATE TABLE `employee_salary_structures` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `payroll_category_id` int(11) default NULL,
  `amount` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `employee_salary_structures`
--


-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `start_date` datetime default NULL,
  `end_date` datetime default NULL,
  `is_common` tinyint(1) default '0',
  `is_holiday` tinyint(1) default '0',
  `is_exam` tinyint(1) default '0',
  `is_due` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_events_on_is_common_and_is_holiday_and_is_exam` (`is_common`,`is_holiday`,`is_exam`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=385 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` VALUES(1, 'Exam', 'Internal Assessment Record May 2012 for CSE - 2K11 A1 - Math', '2012-05-16 11:14:00', '2012-05-16 11:14:00', 0, 0, 1, 0, '2012-05-16 11:15:27', '2012-05-16 11:15:27');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL auto_increment,
  `exam_group_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `start_time` datetime default NULL,
  `end_time` datetime default NULL,
  `maximum_marks` decimal(10,2) default NULL,
  `minimum_marks` decimal(10,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `weightage` int(11) default '0',
  `event_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_exams_on_exam_group_id_and_subject_id` (`exam_group_id`,`subject_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=377 ;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` VALUES(12, 3, 202, '2012-05-16 12:17:00', '2012-05-16 12:17:00', 40.00, 16.00, NULL, 0, 12, '2012-05-16 12:27:23', '2012-05-16 12:27:23');

-- --------------------------------------------------------

--
-- Table structure for table `exam_groups`
--

CREATE TABLE `exam_groups` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `exam_type` varchar(255) collate utf8_unicode_ci default NULL,
  `is_published` tinyint(1) default '0',
  `result_published` tinyint(1) default '0',
  `exam_date` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=73 ;

--
-- Dumping data for table `exam_groups`
--

INSERT INTO `exam_groups` VALUES(3, 'internal marks may-12', 8, 'Marks', 1, 0, '2012-05-16');

-- --------------------------------------------------------

--
-- Table structure for table `exam_scores`
--

CREATE TABLE `exam_scores` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `exam_id` int(11) default NULL,
  `marks` decimal(7,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `remarks` varchar(255) collate utf8_unicode_ci default NULL,
  `is_failed` tinyint(1) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_exam_scores_on_student_id_and_exam_id` (`student_id`,`exam_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11890 ;

--
-- Dumping data for table `exam_scores`
--

INSERT INTO `exam_scores` VALUES(1, 1320, 19, 8.00, NULL, '', NULL, '2012-11-10 05:05:22', '2012-11-10 05:05:22');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_assignments`
--

CREATE TABLE `faculty_assignments` (
  `id` int(2) NOT NULL auto_increment,
  `faculty` varchar(30) NOT NULL,
  `faculty_fb_id` varchar(40) NOT NULL,
  `batch` varchar(10) NOT NULL,
  `department` varchar(10) NOT NULL,
  `post_link` varchar(300) NOT NULL,
  `time` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `faculty_assignments`
--

INSERT INTO `faculty_assignments` VALUES(1, 'Saajan Shridhar', '100005163098296', '09', 'ECE', 'https://www.facebook.com/permalink.php?id=213682468728322&v=wall&story_fbid=4798', '2013-03-16 12:52:16');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_course_material`
--

CREATE TABLE `faculty_course_material` (
  `id` int(2) NOT NULL auto_increment,
  `faculty` varchar(30) NOT NULL,
  `faculty_fb_id` varchar(40) NOT NULL,
  `subject` varchar(40) NOT NULL,
  `batch` varchar(10) NOT NULL,
  `department` varchar(10) NOT NULL,
  `post_link` varchar(300) NOT NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `faculty_course_material`
--

INSERT INTO `faculty_course_material` VALUES(1, 'Saajan Shridhar', '100005163098296', 'OS', '09', 'ECE', 'https://www.facebook.com/permalink.php?id=213682468728322&v=wall&story_fbid=4798', '2013-03-16 12:52:16');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_posts`
--

CREATE TABLE `faculty_posts` (
  `message` varchar(2000) NOT NULL,
  `post_id` varchar(35) NOT NULL,
  `likes` int(4) NOT NULL,
  `comments` int(4) NOT NULL,
  `shares` int(4) NOT NULL,
  `actor_id` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_posts`
--

INSERT INTO `faculty_posts` VALUES('Hello CSE 6th sem,\r\n\r\nThis is your first assignment for Microprocessor 8086.\r\n\r\nSubmission Date - 28/3/13.\r\n\r\nSpecial Instructions -  Use black covers. Do not use glitter pen.', '375747506036_150257425141494', 0, 0, 0, '100000938499983');

-- --------------------------------------------------------

--
-- Table structure for table `fee_collection_discounts`
--

CREATE TABLE `fee_collection_discounts` (
  `id` int(11) NOT NULL auto_increment,
  `type` varchar(255) collate utf8_unicode_ci default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `receiver_id` int(11) default NULL,
  `finance_fee_collection_id` int(11) default NULL,
  `discount` decimal(15,2) default NULL,
  `is_amount` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `fee_collection_discounts`
--


-- --------------------------------------------------------

--
-- Table structure for table `fee_collection_particulars`
--

CREATE TABLE `fee_collection_particulars` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `amount` decimal(12,2) default NULL,
  `finance_fee_collection_id` int(11) default NULL,
  `student_category_id` int(11) default NULL,
  `admission_no` varchar(255) collate utf8_unicode_ci default NULL,
  `student_id` int(11) default NULL,
  `is_deleted` tinyint(1) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `fee_collection_particulars`
--


-- --------------------------------------------------------

--
-- Table structure for table `fee_discounts`
--

CREATE TABLE `fee_discounts` (
  `id` int(11) NOT NULL auto_increment,
  `type` varchar(255) collate utf8_unicode_ci default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `receiver_id` int(11) default NULL,
  `finance_fee_category_id` int(11) default NULL,
  `discount` decimal(15,2) default NULL,
  `is_amount` tinyint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `fee_discounts`
--


-- --------------------------------------------------------

--
-- Table structure for table `finance_donations`
--

CREATE TABLE `finance_donations` (
  `id` int(11) NOT NULL auto_increment,
  `donor` varchar(255) collate utf8_unicode_ci default NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `amount` decimal(15,2) default NULL,
  `transaction_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `transaction_date` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `finance_donations`
--


-- --------------------------------------------------------

--
-- Table structure for table `finance_fees`
--

CREATE TABLE `finance_fees` (
  `id` int(11) NOT NULL auto_increment,
  `fee_collection_id` int(11) default NULL,
  `transaction_id` varchar(255) collate utf8_unicode_ci default NULL,
  `student_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_finance_fees_on_fee_collection_id_and_student_id` (`fee_collection_id`,`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `finance_fees`
--


-- --------------------------------------------------------

--
-- Table structure for table `finance_fee_categories`
--

CREATE TABLE `finance_fee_categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `batch_id` int(11) default NULL,
  `is_deleted` tinyint(1) NOT NULL default '0',
  `is_master` tinyint(1) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `finance_fee_categories`
--

INSERT INTO `finance_fee_categories` VALUES(1, 'test', 'test', 2, 0, 1, '2012-06-12 11:15:26', '2012-06-12 11:15:26');

-- --------------------------------------------------------

--
-- Table structure for table `finance_fee_collections`
--

CREATE TABLE `finance_fee_collections` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `start_date` date default NULL,
  `end_date` date default NULL,
  `due_date` date default NULL,
  `fee_category_id` int(11) default NULL,
  `batch_id` int(11) default NULL,
  `is_deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `index_finance_fee_collections_on_fee_category_id` (`fee_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `finance_fee_collections`
--


-- --------------------------------------------------------

--
-- Table structure for table `finance_fee_particulars`
--

CREATE TABLE `finance_fee_particulars` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `amount` decimal(15,2) default NULL,
  `finance_fee_category_id` int(11) default NULL,
  `student_category_id` int(11) default NULL,
  `admission_no` varchar(255) collate utf8_unicode_ci default NULL,
  `student_id` int(11) default NULL,
  `is_deleted` tinyint(1) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `finance_fee_particulars`
--


-- --------------------------------------------------------

--
-- Table structure for table `finance_fee_structure_elements`
--

CREATE TABLE `finance_fee_structure_elements` (
  `id` int(11) NOT NULL auto_increment,
  `amount` decimal(15,2) default NULL,
  `label` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `student_category_id` int(11) default NULL,
  `student_id` int(11) default NULL,
  `parent_id` int(11) default NULL,
  `fee_collection_id` int(11) default NULL,
  `deleted` tinyint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `finance_fee_structure_elements`
--


-- --------------------------------------------------------

--
-- Table structure for table `finance_transactions`
--

CREATE TABLE `finance_transactions` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `amount` decimal(15,2) default NULL,
  `fine_included` tinyint(1) default '0',
  `category_id` int(11) default NULL,
  `student_id` int(11) default NULL,
  `finance_fees_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `transaction_date` date default NULL,
  `fine_amount` decimal(10,2) default '0.00',
  `master_transaction_id` int(11) default '0',
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `finance_transactions`
--


-- --------------------------------------------------------

--
-- Table structure for table `finance_transaction_categories`
--

CREATE TABLE `finance_transaction_categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `is_income` tinyint(1) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `finance_transaction_categories`
--

INSERT INTO `finance_transaction_categories` VALUES(1, 'Salary', ' ', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `finance_transaction_triggers`
--

CREATE TABLE `finance_transaction_triggers` (
  `id` int(11) NOT NULL auto_increment,
  `finance_category_id` int(11) default NULL,
  `percentage` decimal(8,2) default NULL,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `finance_transaction_triggers`
--


-- --------------------------------------------------------

--
-- Table structure for table `grading_levels`
--

CREATE TABLE `grading_levels` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `min_score` int(11) default NULL,
  `order` int(11) default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_grading_levels_on_batch_id_and_is_deleted` (`batch_id`,`is_deleted`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `grading_levels`
--

INSERT INTO `grading_levels` VALUES(1, 'A', NULL, 90, NULL, 0, '2011-09-14 06:03:45', '2011-09-14 06:03:45');

-- --------------------------------------------------------

--
-- Table structure for table `grouped_exams`
--

CREATE TABLE `grouped_exams` (
  `id` int(11) NOT NULL auto_increment,
  `exam_group_id` int(11) default NULL,
  `batch_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_grouped_exams_on_batch_id` (`batch_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `grouped_exams`
--

INSERT INTO `grouped_exams` VALUES(1, 18, 15);

-- --------------------------------------------------------

--
-- Table structure for table `guardians`
--

CREATE TABLE `guardians` (
  `id` int(11) NOT NULL auto_increment,
  `ward_id` int(11) default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `relation` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `mobile_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `city` varchar(255) collate utf8_unicode_ci default NULL,
  `state` varchar(255) collate utf8_unicode_ci default NULL,
  `country_id` int(11) default NULL,
  `dob` date default NULL,
  `occupation` varchar(255) collate utf8_unicode_ci default NULL,
  `income` varchar(255) collate utf8_unicode_ci default NULL,
  `education` varchar(255) collate utf8_unicode_ci default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1770 ;

--
-- Dumping data for table `guardians`
--

INSERT INTO `guardians` VALUES(1, 1, 'rajiv', 'sharma', 'father', '', '', '', '', '', '', '', '', 76, NULL, '', '', '', '2011-10-12 15:17:45', '2011-10-12 15:17:45');

-- --------------------------------------------------------

--
-- Table structure for table `individual_payslip_categories`
--

CREATE TABLE `individual_payslip_categories` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `salary_date` date default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `amount` varchar(255) collate utf8_unicode_ci default NULL,
  `is_deduction` tinyint(1) default NULL,
  `include_every_month` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `individual_payslip_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `liabilities`
--

CREATE TABLE `liabilities` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `description` text collate utf8_unicode_ci,
  `amount` int(11) default NULL,
  `is_solved` tinyint(1) default '0',
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `liabilities`
--


-- --------------------------------------------------------

--
-- Table structure for table `monthly_payslips`
--

CREATE TABLE `monthly_payslips` (
  `id` int(11) NOT NULL auto_increment,
  `salary_date` date default NULL,
  `employee_id` int(11) default NULL,
  `payroll_category_id` int(11) default NULL,
  `amount` varchar(255) collate utf8_unicode_ci default NULL,
  `is_approved` tinyint(1) NOT NULL default '0',
  `approver_id` int(11) default NULL,
  `is_rejected` tinyint(1) NOT NULL default '0',
  `rejector_id` int(11) default NULL,
  `reason` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `monthly_payslips`
--


-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `content` text collate utf8_unicode_ci,
  `author_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `news`
--


-- --------------------------------------------------------

--
-- Table structure for table `news_comments`
--

CREATE TABLE `news_comments` (
  `id` int(11) NOT NULL auto_increment,
  `content` text collate utf8_unicode_ci,
  `news_id` int(11) default NULL,
  `author_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `news_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `payroll_categories`
--

CREATE TABLE `payroll_categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `percentage` float default NULL,
  `payroll_category_id` int(11) default NULL,
  `is_deduction` tinyint(1) default NULL,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `payroll_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `period_entries`
--

CREATE TABLE `period_entries` (
  `id` int(11) NOT NULL auto_increment,
  `month_date` date default NULL,
  `batch_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `class_timing_id` int(11) default NULL,
  `employee_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_period_entries_on_month_date_and_batch_id` (`month_date`,`batch_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=187983 ;

--
-- Dumping data for table `period_entries`
--

INSERT INTO `period_entries` VALUES(1, '2011-09-01', 2, 139, 187, 169);

-- --------------------------------------------------------

--
-- Table structure for table `privileges`
--

CREATE TABLE `privileges` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `privileges`
--

INSERT INTO `privileges` VALUES(1, 'ExaminationControl', '2011-09-14 06:03:54', '2011-09-14 06:03:54');

-- --------------------------------------------------------

--
-- Table structure for table `privileges_users`
--

CREATE TABLE `privileges_users` (
  `user_id` int(11) default NULL,
  `privilege_id` int(11) default NULL,
  KEY `index_privileges_users_on_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `privileges_users`
--

INSERT INTO `privileges_users` VALUES(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `reminders`
--

CREATE TABLE `reminders` (
  `id` int(11) NOT NULL auto_increment,
  `sender` int(11) default NULL,
  `recipient` int(11) default NULL,
  `subject` varchar(255) collate utf8_unicode_ci default NULL,
  `body` text collate utf8_unicode_ci,
  `is_read` tinyint(1) default '0',
  `is_deleted_by_sender` tinyint(1) default '0',
  `is_deleted_by_recipient` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_reminders_on_recipient` (`recipient`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3499 ;

--
-- Dumping data for table `reminders`
--

INSERT INTO `reminders` VALUES(1, 1, 1, 'test', 'test', 1, 0, 0, '2011-09-22 13:10:59', '2011-09-22 13:11:06');

-- --------------------------------------------------------

--
-- Table structure for table `schema_migrations`
--

CREATE TABLE `schema_migrations` (
  `version` varchar(255) collate utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `schema_migrations`
--

INSERT INTO `schema_migrations` VALUES('20090622100004');

-- --------------------------------------------------------

--
-- Table structure for table `sms_settings`
--

CREATE TABLE `sms_settings` (
  `id` int(11) NOT NULL auto_increment,
  `settings_key` varchar(255) collate utf8_unicode_ci default NULL,
  `is_enabled` tinyint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `sms_settings`
--

INSERT INTO `sms_settings` VALUES(1, 'ApplicationEnabled', 0);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL auto_increment,
  `admission_no` varchar(255) collate utf8_unicode_ci default NULL,
  `class_roll_no` varchar(255) collate utf8_unicode_ci default NULL,
  `admission_date` date default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `middle_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `date_of_birth` date default NULL,
  `gender` varchar(255) collate utf8_unicode_ci default NULL,
  `blood_group` varchar(255) collate utf8_unicode_ci default NULL,
  `birth_place` varchar(255) collate utf8_unicode_ci default NULL,
  `nationality_id` int(11) default NULL,
  `language` varchar(255) collate utf8_unicode_ci default NULL,
  `religion` varchar(255) collate utf8_unicode_ci default NULL,
  `student_category_id` int(11) default NULL,
  `address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `city` varchar(255) collate utf8_unicode_ci default NULL,
  `state` varchar(255) collate utf8_unicode_ci default NULL,
  `pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `country_id` int(11) default NULL,
  `phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `immediate_contact_id` int(11) default NULL,
  `is_sms_enabled` tinyint(1) default '1',
  `photo_file_name` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_content_type` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_data` mediumblob,
  `status_description` varchar(255) collate utf8_unicode_ci default NULL,
  `is_active` tinyint(1) default '1',
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `has_paid_fees` tinyint(1) default '0',
  `photo_file_size` int(11) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_students_on_admission_no` (`admission_no`(10)),
  KEY `index_students_on_first_name_and_middle_name_and_last_name` (`first_name`(10),`middle_name`(10),`last_name`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1937 ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` VALUES(1, '213-08', NULL, '2011-10-12', 'sadhvi', '', 'sharma', 8, '2006-10-12', 'm', '', '', 76, '', 'hindu', 1, '', '', '', '', '', 76, '', '94191-98469', 'sadhvi@mietjammu.in', 1, 1, NULL, NULL, NULL, NULL, 1, 0, '2011-10-12 15:12:55', '2011-10-12 15:18:11', 0, NULL, 146);

-- --------------------------------------------------------

--
-- Table structure for table `students_subjects`
--

CREATE TABLE `students_subjects` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `batch_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_students_subjects_on_student_id_and_subject_id` (`student_id`,`subject_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Dumping data for table `students_subjects`
--

INSERT INTO `students_subjects` VALUES(1, 1163, 421, 6);

-- --------------------------------------------------------

--
-- Table structure for table `student_additional_details`
--

CREATE TABLE `student_additional_details` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `additional_field_id` int(11) default NULL,
  `additional_info` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `student_additional_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `student_additional_fields`
--

CREATE TABLE `student_additional_fields` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `student_additional_fields`
--


-- --------------------------------------------------------

--
-- Table structure for table `student_categories`
--

CREATE TABLE `student_categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `is_deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `student_categories`
--

INSERT INTO `student_categories` VALUES(1, 'Open Merit', 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_previous_datas`
--

CREATE TABLE `student_previous_datas` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `institution` varchar(255) collate utf8_unicode_ci default NULL,
  `year` varchar(255) collate utf8_unicode_ci default NULL,
  `course` varchar(255) collate utf8_unicode_ci default NULL,
  `total_mark` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=184 ;

--
-- Dumping data for table `student_previous_datas`
--

INSERT INTO `student_previous_datas` VALUES(1, 84, 'MIET, JAMMU', '', 'B.E', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_previous_subject_marks`
--

CREATE TABLE `student_previous_subject_marks` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `subject` varchar(255) collate utf8_unicode_ci default NULL,
  `mark` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `student_previous_subject_marks`
--


-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `no_exams` tinyint(1) default '0',
  `max_weekly_classes` int(11) default NULL,
  `elective_group_id` int(11) default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_subjects_on_batch_id_and_elective_group_id_and_is_deleted` (`batch_id`,`elective_group_id`,`is_deleted`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=563 ;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` VALUES(1, 'Advanced Microprocessors', 'COM-601', 10, 0, 4, NULL, 1, '2012-01-25 12:29:29', '2012-08-13 12:51:01');

-- --------------------------------------------------------

--
-- Table structure for table `sync_status`
--

CREATE TABLE `sync_status` (
  `id` int(2) NOT NULL,
  `last_table_synced` varchar(35) NOT NULL default '',
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sync_status`
--

INSERT INTO `sync_status` VALUES(0, 'additional_exam_groups', '2013-03-20 17:29:18');

-- --------------------------------------------------------

--
-- Table structure for table `timetable_entries`
--

CREATE TABLE `timetable_entries` (
  `id` int(11) NOT NULL auto_increment,
  `batch_id` int(11) default NULL,
  `weekday_id` int(11) default NULL,
  `class_timing_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `employee_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `by_timetable` (`weekday_id`,`batch_id`,`class_timing_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1891 ;

--
-- Dumping data for table `timetable_entries`
--

INSERT INTO `timetable_entries` VALUES(241, 8, 1, 51, 51, 157);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) collate utf8_unicode_ci default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `admin` tinyint(1) default NULL,
  `student` tinyint(1) default NULL,
  `employee` tinyint(1) default NULL,
  `hashed_password` varchar(255) collate utf8_unicode_ci default NULL,
  `salt` varchar(255) collate utf8_unicode_ci default NULL,
  `reset_password_code` varchar(255) collate utf8_unicode_ci default NULL,
  `reset_password_code_until` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_users_on_username` (`username`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2153 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES(1, 'admin', 'Fedena', 'Administrator', 'noreplyadmin@fedena.com', 1, 0, 0, '355f0320a0e06200d1bd69c7d8a0e5db5993d990', 'z3v2Uuq2', NULL, NULL, '2011-09-14 06:03:50', '2011-09-14 06:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `user_records`
--

CREATE TABLE `user_records` (
  `first_name` varchar(20) default NULL,
  `last_name` varchar(20) default NULL,
  `roll_no` varchar(10) default NULL,
  `department` varchar(20) default NULL,
  `batch` varchar(15) default NULL,
  `fb_id` varchar(30) default NULL,
  `attendance_notified` int(2) default '0',
  `result_notified` int(2) default '0',
  `should_notify_attendance` tinyint(2) NOT NULL default '1',
  `should_notify_result` tinyint(2) NOT NULL default '1',
  `should_notify_faculty_query` tinyint(2) NOT NULL default '1',
  `is_not_verified` int(2) NOT NULL default '0',
  `student` int(2) NOT NULL default '0',
  `faculty` int(2) NOT NULL default '0',
  `should_notify_knowledge` tinyint(2) NOT NULL default '1',
  `is_notified_general` int(2) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_records`
--

INSERT INTO `user_records` VALUES('Saajan', 'Shridhar', '208', 'CSE', '10', '1267729545', 0, 0, 1, 1, 1, 0, 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_reports`
--

CREATE TABLE `user_reports` (
  `id` int(2) NOT NULL auto_increment,
  `facebook_id` varchar(30) NOT NULL,
  `message` varchar(2000) NOT NULL,
  `time` varchar(15) NOT NULL,
  `is_resolved` tinyint(2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=76 ;

--
-- Dumping data for table `user_reports`
--

INSERT INTO `user_reports` VALUES(1, '1675866799', '-----AND the User said----Developer team,\r\nMy Name Is Ashish Deep Singh.\r\nI am a B.E. first semester student of computer science department.\r\nMy roll no is 237 and my DOB is 22-02-1994 on the college database.\r\nYet I am not able to get my records .\r\n\r\n', '2013-02-22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(2) NOT NULL auto_increment,
  `name` varchar(25) NOT NULL,
  `details` varchar(25) NOT NULL,
  `fb_id` varchar(25) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=499 ;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` VALUES(1, 'Saajan Shridhar', '208-CSE-10', '1267729545');

-- --------------------------------------------------------

--
-- Table structure for table `weekdays`
--

CREATE TABLE `weekdays` (
  `id` int(11) NOT NULL auto_increment,
  `batch_id` int(11) default NULL,
  `weekday` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_weekdays_on_batch_id` (`batch_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `weekdays`
--

INSERT INTO `weekdays` VALUES(1, NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `xmls`
--

CREATE TABLE `xmls` (
  `id` int(11) NOT NULL auto_increment,
  `finance_name` varchar(255) collate utf8_unicode_ci default NULL,
  `ledger_name` varchar(255) collate utf8_unicode_ci default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `xmls`
--

INSERT INTO `xmls` VALUES(1, 'Salary', '', '2011-09-14 06:04:00', '2011-09-14 06:04:00');
